$(function () {
  layout_change("light");
  layout_theme_contrast_change("false");
  change_box_container("false");
  layout_caption_change("true");
  layout_rtl_change("false");
  preset_change("preset-2");
});