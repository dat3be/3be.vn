$(function () {
    layout_change('light');
    layout_theme_contrast_change('false');
    change_box_container('false');
    layout_caption_change('true');
    layout_rtl_change('false');
    preset_change('preset-2');
});
console.log('%cĐược phát triển bởi: %cLương Bình Dương %c- https://fb.com/luongbinhduong.dev', 'color: #007bff; font-weight: bold; font-size: 20px;', 'color: #007bff; font-weight: bold; font-size: 20px;', 'color: #007bff; font-weight: bold; font-size: 20px;');
