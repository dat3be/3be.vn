<footer class="main-footer">
    <strong>Copyright &copy; 2024<a href=""> KHANGAPI</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 2.0
    </div>
</footer>
<!-- jQuery -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
$.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/bootstrap/js/bootstrap.bundle.min.js">
</script>
<!-- ChartJS -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/moment/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/daterangepicker/daterangepicker.js">
</script>
<!-- Tempusdominus Bootstrap 4 -->
<script
    src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js">
</script>
<!-- Summernote -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/summernote/summernote-bs4.min.js">
</script>
<!-- overlayScrollbars -->
<script
    src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js">
</script>
<!-- AdminLTE App -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="https://cdn.jsdelivr.net/gh/quangtuu2006/admin_lite@main/dist/js/pages/dashboard.js"></script>