<?php
require $_SERVER['DOCUMENT_ROOT'].'/hethong/config.php';
require $_SERVER['DOCUMENT_ROOT'].'/hethong/Google/vendor/autoload.php';
$client_id = "483243801853-5kp6lg1idvvk5d858too2lr1js3q5jtf.apps.googleusercontent.com"; 
$client_secret = "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"; 
$redirect_uri = "https://dichvumight.com/auth/login-google"; 
$client = new Google_Client();
$client->setClientId($client_id);
$client->setClientSecret($client_secret);
$client->setRedirectUri($redirect_uri);
$client->addScope("email");
$client->addScope("profile");
$service = new Google_Service_Oauth2($client);
if (isset($_GET['logout'])) {
    unset($_SESSION['access_token']);
    $client->revokeToken();
    session_destroy();
    header("Location: /auth/login-google");
    exit();
}
if (isset($_GET['code'])) {
    $code = $_GET['code'];

    try {
        
        $token = $client->fetchAccessTokenWithAuthCode($code);
        if (!isset($token['error'])) {
            $client->setAccessToken($token['access_token']);

            $_SESSION['access_token'] = $token['access_token'];

            $userInfo = $service->userinfo->get();
            $gg_id = $userInfo->id;
            $gg_email = $userInfo->email;
            $pass = sha1(md5($gg_id)); 
            $check = $ketnoi->query("SELECT * FROM `users` WHERE `username` = '$gg_id' AND `email` = '$gg_email' ")->fetch_array();
            $check_mail = $ketnoi->query("SELECT * FROM `users` WHERE `email` = '$gg_email' ");
       
           if($check){
            $now_ss = random('0123456789qwertyuiopasdfghjlkzxcvbnmQEWRWROIWCJHSCNJKFBJWQ', 32);
            $ketnoi->query("UPDATE `users` SET `session` = '$now_ss' WHERE `username` = '" . $gg_id . "'  ");
            $_SESSION['session'] = $now_ss;
            header("location: /home"); 
           }else{
                if($check_mail->num_rows != 0){
             die('Email của bạn đã được đăng ký trên hệ thống của chúng tôi từ trước');
        }
             $api_key = random('0123456789qwertyuiopasdfghjlkzxcvbnmQEWRWROIWCJHSCNJKFBJWQ', 25);
             $api = $ketnoi->query("INSERT INTO `users` SET
            `username` = '$gg_id',
            `password` = '$pass',
            `loai` = 'Google',
            `email` = '$gg_email',
            `api_key` = '$api_key',
            `chiet_khau` = '0',
            `level` = '0',
            `tong_nap` = '0',
            `money` = '0',
            `bannd` = '0',
            `ip` = '$ip_address',
            `otpcode` = '',
            `session` = '',
            `time` = '".$time."' ");
 
            $now_ss = random('0123456789qwertyuiopasdfghjlkzxcvbnmQEWRWROIWCJHSCNJKFBJWQ', 32);
            $ketnoi->query("UPDATE `users` SET `session` = '$now_ss' WHERE `username` = '" . $gg_id . "' ");
            $_SESSION['session'] = $now_ss;
            header("location: /home");

           }
        } else {
            echo "Error fetching access token: " . $token['error'];
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    $authUrl = $client->createAuthUrl();
    header("Location: $authUrl");
    exit();
}
?>
